# DAAI_N3.02 - Gold Data

## Thứ tự chạy
1. Chạy `sql/DAAI_N3.02_Schema.sql`.
2. Chạy `python/DAAI_N3.02_Load.py` để nạp các file Silver vào SQL Server.
3. Chạy `sql/DAAI_N3.02_DW.sql`.
4. Chạy `sql/DAAI_N3.02_Gold.sql`.
5. Chạy `sql/DAAI_N3.02_Check.sql` để kiểm tra.

## Cấu trúc
- `silver.*`: 1 file Silver tương ứng 1 table SQL.
- `dw.*`: DimDate, DimProduct, DimOrderStatus, FactSales, FactInventorySnapshot.
- `gold.*`: 5 bảng phục vụ PS1-PS5.

## Python loader
```bat
pip install -r python\requirements.txt
python python\DAAI_N3.02_Load.py ^
  --source-dir "C:\...\DAAI_N3.02_Silver\silver_data" ^
  --server "localhost\SQLEXPRESS" ^
  --trusted
```
