from pathlib import Path
import argparse
import re
import pandas as pd
import pyodbc

DATE_HINTS = {"date", "snapshot_date", "order_date", "return_date", "signup_date", "ship_date", "delivery_date", "join_date"}


def q(name: str) -> str:
    return "[" + name.replace("]", "]]" ) + "]"


def sql_type(series: pd.Series, col: str) -> str:
    # // Xác định kiểu cột SQL
    c = col.lower()
    if c in DATE_HINTS or c.endswith("_date"):
        return "DATE NULL"
    if pd.api.types.is_bool_dtype(series):
        return "BIT NULL"
    if pd.api.types.is_integer_dtype(series):
        return "BIGINT NULL"
    if pd.api.types.is_float_dtype(series):
        return "DECIMAL(19,6) NULL"
    return "NVARCHAR(MAX) NULL"


def normalize_frame(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for col in out.columns:
        c = col.lower()
        if c in DATE_HINTS or c.endswith("_date"):
            out[col] = pd.to_datetime(out[col], errors="coerce").dt.date
    return out.astype(object).where(pd.notnull(out), None)


def connection_string(args) -> str:
    # // Tạo chuỗi kết nối
    base = f"DRIVER={{{args.driver}}};SERVER={args.server};DATABASE={args.database};TrustServerCertificate=yes;"
    if args.trusted:
        return base + "Trusted_Connection=yes;"
    if not args.user or not args.password:
        raise ValueError("SQL Authentication cần --user và --password")
    return base + f"UID={args.user};PWD={args.password};"


def create_table(cur, table_name: str, df: pd.DataFrame):
    # // Tạo bảng theo file Silver
    full = f"[silver].{q(table_name)}"
    cur.execute(f"IF OBJECT_ID(N'{full}', N'U') IS NOT NULL DROP TABLE {full};")
    cols = ",\n    ".join(f"{q(c)} {sql_type(df[c], c)}" for c in df.columns)
    cur.execute(f"CREATE TABLE {full} (\n    {cols}\n);")


def insert_df(cur, table_name: str, df: pd.DataFrame, batch_size=10000):
    # // Nạp dữ liệu theo batch
    full = f"[silver].{q(table_name)}"
    cols = list(df.columns)
    sql = f"INSERT INTO {full} ({','.join(q(c) for c in cols)}) VALUES ({','.join('?' for _ in cols)})"
    cur.fast_executemany = True
    rows = list(normalize_frame(df).itertuples(index=False, name=None))
    for i in range(0, len(rows), batch_size):
        cur.executemany(sql, rows[i:i+batch_size])
        print(f"  {table_name}: {min(i+batch_size, len(rows)):,}/{len(rows):,}")


def main():
    # // Nạp toàn bộ Silver vào SQL Server
    ap = argparse.ArgumentParser()
    ap.add_argument("--source-dir", required=True, help="Thư mục Problem2_Silver_Data/silver_data")
    ap.add_argument("--server", required=True, help=r"Ví dụ localhost\SQLEXPRESS")
    ap.add_argument("--database", default="Problem2_GoldDW")
    ap.add_argument("--driver", default="ODBC Driver 18 for SQL Server")
    ap.add_argument("--trusted", action="store_true")
    ap.add_argument("--user")
    ap.add_argument("--password")
    args = ap.parse_args()

    src = Path(args.source_dir)
    files = sorted(src.glob("*_silver.csv"))
    if not files:
        raise FileNotFoundError("Không thấy *_silver.csv")

    conn = pyodbc.connect(connection_string(args), autocommit=False)
    try:
        cur = conn.cursor()
        cur.execute("IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name='silver') EXEC('CREATE SCHEMA silver');")
        conn.commit()

        for f in files:
            table = re.sub(r"[^0-9A-Za-z_]", "_", f.stem)
            df = pd.read_csv(f, low_memory=False)
            print(f"{f.name} -> silver.{table} | {len(df):,} rows x {len(df.columns)} cols")
            create_table(cur, table, df)
            insert_df(cur, table, df)
            conn.commit()

        print(f"Hoàn tất: {len(files)} Silver files -> {len(files)} SQL tables.")
    finally:
        conn.close()

if __name__ == "__main__":
    main()
