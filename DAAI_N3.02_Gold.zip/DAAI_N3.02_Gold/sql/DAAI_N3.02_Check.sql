USE Problem2_GoldDW;
GO

-- // Chạy ETL và Gold
EXEC etl.usp_LoadDW;
EXEC gold.usp_RefreshProblem2;
GO

-- // Kiểm tra kết quả
SELECT 'DimProduct' AS TableName, COUNT(*) AS RowCount FROM dw.DimProduct
UNION ALL SELECT 'FactSales', COUNT(*) FROM dw.FactSales
UNION ALL SELECT 'FactInventorySnapshot', COUNT(*) FROM dw.FactInventorySnapshot;

SELECT MIN(PeriodStart) PeriodStart, MAX(PeriodEnd) PeriodEnd,
       SUM(NetRevenue4M) TotalNetRevenue4M,
       SUM(CASE WHEN RevenueRank<=5 THEN RevenueShare ELSE 0 END) Top5Share,
       SUM(CASE WHEN NetRevenue4M>0 THEN 1 ELSE 0 END) ActiveSKU
FROM gold.PS1_ProductRanking4M;
SELECT * FROM gold.vw_PS1_Top5;
SELECT * FROM gold.vw_PS1_Bottom5;

SELECT
    SUM(CASE WHEN IsEligible=1 THEN 1 ELSE 0 END) EligibleSKU,
    MAX(HighQtyThreshold) P75_NetQuantity,
    MAX(PearsonR) PearsonR,
    SUM(CASE WHEN GroupLabel='A' THEN 1 ELSE 0 END) GroupA_SKU,
    SUM(CASE WHEN GroupLabel='A' THEN NetRevenue ELSE 0 END) / NULLIF(SUM(CASE WHEN IsEligible=1 THEN NetRevenue ELSE 0 END),0) AS GroupA_RevenueShare,
    SUM(CASE WHEN GroupLabel='A' THEN GrossProfit ELSE 0 END) / NULLIF(SUM(CASE WHEN GroupLabel='A' THEN NetRevenue ELSE 0 END),0) AS GroupA_GrossMargin
FROM gold.PS2_QuantityRevenue;

SELECT * FROM gold.vw_PS3_Category ORDER BY NetRevenue DESC;

SELECT * FROM gold.vw_PS4_Category ORDER BY AvgSellThrough DESC;

SELECT * FROM gold.vw_PS5_ABCSummary ORDER BY ABCClass;
SELECT SUM(CASE WHEN NetRevenue=0 THEN 1 ELSE 0 END) AS ZeroRevenueSKU FROM gold.PS5_ABC;
GO
