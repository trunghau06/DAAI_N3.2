USE Problem2_GoldDW;
GO

-- // Nạp dữ liệu vào Data Warehouse
CREATE OR ALTER PROCEDURE etl.usp_LoadDW
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRY
        BEGIN TRAN;

        TRUNCATE TABLE dw.FactSales;
        TRUNCATE TABLE dw.FactInventorySnapshot;
        DELETE FROM dw.DimOrderStatus;
        DELETE FROM dw.DimProduct;
        DELETE FROM dw.DimDate;
        DBCC CHECKIDENT ('dw.FactSales', RESEED, 0) WITH NO_INFOMSGS;
        DBCC CHECKIDENT ('dw.FactInventorySnapshot', RESEED, 0) WITH NO_INFOMSGS;
        DBCC CHECKIDENT ('dw.DimOrderStatus', RESEED, 0) WITH NO_INFOMSGS;
        DBCC CHECKIDENT ('dw.DimProduct', RESEED, 0) WITH NO_INFOMSGS;

        -- // Nạp Dimension
        DECLARE @StartDate DATE, @EndDate DATE;
        SELECT @StartDate = MIN(d), @EndDate = MAX(d)
        FROM (
            SELECT MIN(order_date) AS d FROM silver.orders_silver
            UNION ALL
            SELECT MAX(order_date) FROM silver.orders_silver
            UNION ALL
            SELECT MIN(snapshot_date) FROM silver.inventory_silver
            UNION ALL
            SELECT MAX(snapshot_date) FROM silver.inventory_silver
        ) x;

        ;WITH d AS (
            SELECT @StartDate AS FullDate
            UNION ALL
            SELECT DATEADD(DAY, 1, FullDate)
            FROM d
            WHERE FullDate < @EndDate
        )
        INSERT INTO dw.DimDate(DateKey, FullDate, DayNo, MonthNo, MonthName, QuarterNo, YearNo)
        SELECT
            CONVERT(INT, CONVERT(CHAR(8), FullDate, 112)),
            FullDate,
            DAY(FullDate),
            MONTH(FullDate),
            DATENAME(MONTH, FullDate),
            DATEPART(QUARTER, FullDate),
            YEAR(FullDate)
        FROM d
        OPTION (MAXRECURSION 0);

        INSERT INTO dw.DimProduct(ProductID, ProductName, Category, Segment, Size, Color, ListPrice, UnitCOGS)
        SELECT product_id, product_name, category, segment, size, color, price, cogs
        FROM silver.products_silver;

        INSERT INTO dw.DimOrderStatus(OrderStatus)
        SELECT DISTINCT order_status
        FROM silver.orders_silver
        WHERE order_status IS NOT NULL;

        -- // Tổng hợp bán hàng và hoàn trả
        ;WITH SalesAgg AS (
            SELECT
                order_id,
                product_id,
                SUM(ISNULL(quantity,0)) AS SoldQuantity,
                SUM(CAST(ISNULL(quantity,0) AS DECIMAL(19,4)) * ISNULL(unit_price,0)) AS GrossSales,
                SUM(ISNULL(discount_amount,0)) AS DiscountAmount,
                SUM(CAST(ISNULL(quantity,0) AS DECIMAL(19,4)) * ISNULL(unit_price,0) - ISNULL(discount_amount,0)) AS SalesAfterDiscount
            FROM silver.order_items_silver
            GROUP BY order_id, product_id
        ),
        ReturnAgg AS (
            SELECT
                order_id,
                product_id,
                SUM(ISNULL(return_quantity,0)) AS ReturnQuantity,
                SUM(ISNULL(refund_amount,0)) AS RefundAmount
            FROM silver.returns_silver
            GROUP BY order_id, product_id
        )
        INSERT INTO dw.FactSales(
            OrderID, DateKey, ProductKey, StatusKey,
            SoldQuantity, ReturnQuantity, NetQuantity,
            GrossSales, DiscountAmount, SalesAfterDiscount,
            RefundAmount, NetRevenue, NetCOGS, GrossProfit, GrossMargin
        )
        SELECT
            s.order_id,
            d.DateKey,
            p.ProductKey,
            os.StatusKey,
            s.SoldQuantity,
            ISNULL(r.ReturnQuantity,0),
            calc.NetQuantity,
            s.GrossSales,
            s.DiscountAmount,
            s.SalesAfterDiscount,
            ISNULL(r.RefundAmount,0),
            calc.NetRevenue,
            calc2.NetCOGS,
            calc.NetRevenue - calc2.NetCOGS,
            CASE WHEN calc.NetRevenue > 0
                 THEN (calc.NetRevenue - calc2.NetCOGS) / NULLIF(calc.NetRevenue,0)
                 ELSE NULL END
        FROM SalesAgg s
        JOIN silver.orders_silver o ON o.order_id = s.order_id
        JOIN dw.DimDate d ON d.FullDate = o.order_date
        JOIN dw.DimProduct p ON p.ProductID = s.product_id
        JOIN dw.DimOrderStatus os ON os.OrderStatus = o.order_status
        LEFT JOIN ReturnAgg r ON r.order_id = s.order_id AND r.product_id = s.product_id
        CROSS APPLY (
            SELECT
                s.SoldQuantity - ISNULL(r.ReturnQuantity,0) AS NetQuantity,
                s.SalesAfterDiscount - ISNULL(r.RefundAmount,0) AS NetRevenue
        ) calc
        CROSS APPLY (
            SELECT CAST(calc.NetQuantity AS DECIMAL(19,4)) * p.UnitCOGS AS NetCOGS
        ) calc2;

        -- // Nạp tồn kho
        INSERT INTO dw.FactInventorySnapshot(
            DateKey, ProductKey, StockOnHand, UnitsReceived, UnitsSold, StockoutDays,
            DaysOfSupply, FillRate, StockoutFlag, OverstockFlag, ReorderFlag, SellThroughRate
        )
        SELECT
            d.DateKey,
            p.ProductKey,
            i.stock_on_hand,
            i.units_received,
            i.units_sold,
            i.stockout_days,
            i.days_of_supply,
            i.fill_rate,
            i.stockout_flag,
            i.overstock_flag,
            i.reorder_flag,
            i.sell_through_rate
        FROM silver.inventory_silver i
        JOIN dw.DimDate d ON d.FullDate = i.snapshot_date
        JOIN dw.DimProduct p ON p.ProductID = i.product_id;

        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH
END;
GO
