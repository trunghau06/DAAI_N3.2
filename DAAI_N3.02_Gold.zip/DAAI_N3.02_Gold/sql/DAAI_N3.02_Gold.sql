USE Problem2_GoldDW;
GO

-- // Tạo các bảng Gold
DROP VIEW IF EXISTS gold.vw_PS5_ABCSummary;
DROP VIEW IF EXISTS gold.vw_PS4_Category;
DROP VIEW IF EXISTS gold.vw_PS3_Category;
DROP VIEW IF EXISTS gold.vw_PS2_GroupA;
DROP VIEW IF EXISTS gold.vw_PS1_Bottom5;
DROP VIEW IF EXISTS gold.vw_PS1_Top5;
GO

DROP TABLE IF EXISTS gold.PS5_ABC;
DROP TABLE IF EXISTS gold.PS4_InventoryTurnover;
DROP TABLE IF EXISTS gold.PS3_ClassPerformance;
DROP TABLE IF EXISTS gold.PS2_QuantityRevenue;
DROP TABLE IF EXISTS gold.PS1_ProductRanking4M;
GO

CREATE TABLE gold.PS1_ProductRanking4M (
    RevenueRank             INT            NOT NULL,
    ProductID               INT            NOT NULL,
    ProductName             NVARCHAR(200)  NULL,
    Category                NVARCHAR(100)  NULL,
    Segment                 NVARCHAR(100)  NULL,
    PeriodStart             DATE           NOT NULL,
    PeriodEnd               DATE           NOT NULL,
    NetRevenue4M            DECIMAL(19,4)  NOT NULL,
    NetQuantity4M           INT            NOT NULL,
    Orders4M                INT            NOT NULL,
    RevenueShare            DECIMAL(19,10) NULL,
    CumulativeRevenueShare  DECIMAL(19,10) NULL,
    InventorySnapshotDate   DATE           NULL,
    StockOnHand             INT            NULL,
    SellThroughRate         DECIMAL(19,6)  NULL,
    DaysOfSupply            DECIMAL(19,4)  NULL,
    OverstockFlag           BIT            NULL,
    InventoryCostValue      DECIMAL(19,4)  NULL,
    InventoryRiskFlag       BIT            NOT NULL
);

CREATE TABLE gold.PS2_QuantityRevenue (
    ProductID          INT            NOT NULL,
    ProductName        NVARCHAR(200)  NULL,
    Category           NVARCHAR(100)  NULL,
    Segment            NVARCHAR(100)  NULL,
    SoldQuantity       INT            NOT NULL,
    ReturnQuantity     INT            NOT NULL,
    NetQuantity        INT            NOT NULL,
    GrossSales         DECIMAL(19,4)  NOT NULL,
    DiscountAmount     DECIMAL(19,4)  NOT NULL,
    RefundAmount       DECIMAL(19,4)  NOT NULL,
    NetRevenue         DECIMAL(19,4)  NOT NULL,
    NetCOGS            DECIMAL(19,4)  NULL,
    GrossProfit        DECIMAL(19,4)  NULL,
    GrossMargin        DECIMAL(19,8)  NULL,
    HighQtyThreshold   DECIMAL(19,4)  NULL,
    MarginThreshold    DECIMAL(19,8)  NOT NULL,
    GroupLabel         CHAR(1)        NULL,
    IsEligible         BIT            NOT NULL,
    PearsonR           DECIMAL(19,10) NULL
);

CREATE TABLE gold.PS3_ClassPerformance (
    ClassLevel           NVARCHAR(20)   NOT NULL,
    ClassName            NVARCHAR(100)  NOT NULL,
    SoldQuantity         BIGINT         NOT NULL,
    ReturnQuantity       BIGINT         NOT NULL,
    NetQuantity          BIGINT         NOT NULL,
    QuantityContribution DECIMAL(19,10) NULL,
    NetRevenue           DECIMAL(19,4)  NOT NULL,
    RevenueContribution  DECIMAL(19,10) NULL,
    RevenuePerUnit       DECIMAL(19,4)  NULL,
    GrossProfit          DECIMAL(19,4)  NULL,
    GrossMargin          DECIMAL(19,8)  NULL,
    ReturnRate           DECIMAL(19,8)  NULL
);

CREATE TABLE gold.PS4_InventoryTurnover (
    ClassLevel        NVARCHAR(20)   NOT NULL,
    ClassName         NVARCHAR(100)  NOT NULL,
    NetQuantity       BIGINT         NULL,
    QuantityShare     DECIMAL(19,10) NULL,
    NetRevenue        DECIMAL(19,4)  NULL,
    AvgSellThrough    DECIMAL(19,8)  NULL,
    AvgDaysOfSupply   DECIMAL(19,4)  NULL,
    AvgFillRate       DECIMAL(19,8)  NULL,
    StockoutRate      DECIMAL(19,8)  NULL,
    OverstockRate     DECIMAL(19,8)  NULL,
    CatalogSKU        INT            NULL,
    InventorySKU      INT            NULL,
    InventoryCoverage DECIMAL(19,8)  NULL,
    TurnoverClass     NVARCHAR(30)   NULL
);

CREATE TABLE gold.PS5_ABC (
    ProductRank             INT            NOT NULL,
    ProductID               INT            NOT NULL,
    ProductName             NVARCHAR(200)  NULL,
    Category                NVARCHAR(100)  NULL,
    Segment                 NVARCHAR(100)  NULL,
    NetRevenue              DECIMAL(19,4)  NOT NULL,
    NetQuantity             INT            NOT NULL,
    Orders                  INT            NOT NULL,
    RevenueShare            DECIMAL(19,10) NULL,
    CumulativeRevenueShare  DECIMAL(19,10) NULL,
    ABCClass                CHAR(1)        NOT NULL,
    IsActiveSKU             BIT            NOT NULL
);
GO

-- // Tính Gold cho 5 Problem Statement
CREATE OR ALTER PROCEDURE gold.usp_RefreshProblem2
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @MarginThreshold DECIMAL(19,8) = 0.10;

    BEGIN TRY
        BEGIN TRAN;
        TRUNCATE TABLE gold.PS1_ProductRanking4M;
        TRUNCATE TABLE gold.PS2_QuantityRevenue;
        TRUNCATE TABLE gold.PS3_ClassPerformance;
        TRUNCATE TABLE gold.PS4_InventoryTurnover;
        TRUNCATE TABLE gold.PS5_ABC;

        -- // Chuẩn bị giao dịch hợp lệ
        DROP TABLE IF EXISTS #CompletedSales;
        SELECT fs.*, p.ProductID, p.ProductName, p.Category, p.Segment, p.UnitCOGS, d.FullDate
        INTO #CompletedSales
        FROM dw.FactSales fs
        JOIN dw.DimOrderStatus s ON s.StatusKey = fs.StatusKey
        JOIN dw.DimProduct p ON p.ProductKey = fs.ProductKey
        JOIN dw.DimDate d ON d.DateKey = fs.DateKey
        WHERE s.OrderStatus IN (N'delivered', N'returned');

        -- // PS1: xếp hạng 4 tháng
        DECLARE @MaxOrderDate DATE = (SELECT MAX(FullDate) FROM #CompletedSales);
        DECLARE @PS1End DATE = CASE WHEN @MaxOrderDate = EOMONTH(@MaxOrderDate)
                                    THEN @MaxOrderDate ELSE EOMONTH(@MaxOrderDate, -1) END;
        DECLARE @PS1Start DATE = DATEADD(MONTH, -3, DATEFROMPARTS(YEAR(@PS1End), MONTH(@PS1End), 1));

        DROP TABLE IF EXISTS #PS1Base;
        SELECT
            p.ProductKey, p.ProductID, p.ProductName, p.Category, p.Segment, p.UnitCOGS,
            CAST(ISNULL(SUM(CASE WHEN c.FullDate BETWEEN @PS1Start AND @PS1End THEN c.NetRevenue END),0) AS DECIMAL(19,4)) AS NetRevenue4M,
            CAST(ISNULL(SUM(CASE WHEN c.FullDate BETWEEN @PS1Start AND @PS1End THEN c.NetQuantity END),0) AS INT) AS NetQuantity4M,
            COUNT(DISTINCT CASE WHEN c.FullDate BETWEEN @PS1Start AND @PS1End THEN c.OrderID END) AS Orders4M
        INTO #PS1Base
        FROM dw.DimProduct p
        LEFT JOIN #CompletedSales c ON c.ProductKey = p.ProductKey
        GROUP BY p.ProductKey, p.ProductID, p.ProductName, p.Category, p.Segment, p.UnitCOGS;

        DROP TABLE IF EXISTS #PS1Ranked;
        ;WITH r AS (
            SELECT *,
                ROW_NUMBER() OVER (ORDER BY NetRevenue4M DESC, NetQuantity4M DESC, ProductID ASC) AS RevenueRank,
                CAST(NetRevenue4M / NULLIF(SUM(NetRevenue4M) OVER (),0) AS DECIMAL(19,10)) AS RevenueShare
            FROM #PS1Base
        )
        SELECT *,
            CAST(SUM(RevenueShare) OVER (ORDER BY RevenueRank ROWS UNBOUNDED PRECEDING) AS DECIMAL(19,10)) AS CumulativeRevenueShare
        INTO #PS1Ranked
        FROM r;

        DROP TABLE IF EXISTS #InvEnd;
        ;WITH x AS (
            SELECT
                fi.ProductKey,
                d.FullDate,
                fi.StockOnHand,
                fi.SellThroughRate,
                fi.DaysOfSupply,
                fi.OverstockFlag,
                ROW_NUMBER() OVER (PARTITION BY fi.ProductKey ORDER BY d.FullDate DESC) AS rn
            FROM dw.FactInventorySnapshot fi
            JOIN dw.DimDate d ON d.DateKey = fi.DateKey
            WHERE d.FullDate <= @PS1End
        )
        SELECT * INTO #InvEnd FROM x WHERE rn = 1;

        INSERT INTO gold.PS1_ProductRanking4M
        SELECT
            r.RevenueRank, r.ProductID, r.ProductName, r.Category, r.Segment,
            @PS1Start, @PS1End, r.NetRevenue4M, r.NetQuantity4M, r.Orders4M,
            r.RevenueShare, r.CumulativeRevenueShare,
            i.FullDate, i.StockOnHand, i.SellThroughRate, i.DaysOfSupply, i.OverstockFlag,
            CAST(i.StockOnHand * r.UnitCOGS AS DECIMAL(19,4)),
            CAST(CASE WHEN r.NetRevenue4M <= 0 AND ISNULL(i.StockOnHand,0) > 0 THEN 1 ELSE 0 END AS BIT)
        FROM #PS1Ranked r
        LEFT JOIN #InvEnd i ON i.ProductKey = r.ProductKey;

        -- // PS2: số lượng và doanh thu
        DROP TABLE IF EXISTS #PS2Base;
        SELECT
            p.ProductKey, p.ProductID, p.ProductName, p.Category, p.Segment,
            ISNULL(SUM(c.SoldQuantity),0) AS SoldQuantity,
            ISNULL(SUM(c.ReturnQuantity),0) AS ReturnQuantity,
            ISNULL(SUM(c.NetQuantity),0) AS NetQuantity,
            CAST(ISNULL(SUM(c.GrossSales),0) AS DECIMAL(19,4)) AS GrossSales,
            CAST(ISNULL(SUM(c.DiscountAmount),0) AS DECIMAL(19,4)) AS DiscountAmount,
            CAST(ISNULL(SUM(c.RefundAmount),0) AS DECIMAL(19,4)) AS RefundAmount,
            CAST(ISNULL(SUM(c.NetRevenue),0) AS DECIMAL(19,4)) AS NetRevenue,
            CAST(ISNULL(SUM(c.NetCOGS),0) AS DECIMAL(19,4)) AS NetCOGS,
            CAST(ISNULL(SUM(c.GrossProfit),0) AS DECIMAL(19,4)) AS GrossProfit
        INTO #PS2Base
        FROM dw.DimProduct p
        LEFT JOIN #CompletedSales c ON c.ProductKey = p.ProductKey
        GROUP BY p.ProductKey, p.ProductID, p.ProductName, p.Category, p.Segment;

        ALTER TABLE #PS2Base ADD GrossMargin DECIMAL(19,8) NULL, IsEligible BIT NULL;
        UPDATE #PS2Base
        SET GrossMargin = CASE WHEN NetRevenue > 0 THEN GrossProfit / NULLIF(NetRevenue,0) END,
            IsEligible = CASE WHEN NetQuantity > 0 AND NetRevenue > 0 AND NetCOGS IS NOT NULL THEN 1 ELSE 0 END;

        DECLARE @H DECIMAL(19,4);
        SELECT TOP (1) @H = PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY CAST(NetQuantity AS FLOAT)) OVER ()
        FROM #PS2Base WHERE IsEligible = 1;

        DECLARE @Pearson FLOAT = NULL;
        ;WITH z AS (
            SELECT
                COUNT(*) AS n,
                SUM(CAST(NetQuantity AS FLOAT)) sx,
                SUM(CAST(NetRevenue AS FLOAT)) sy,
                SUM(CAST(NetQuantity AS FLOAT) * CAST(NetRevenue AS FLOAT)) sxy,
                SUM(CAST(NetQuantity AS FLOAT) * CAST(NetQuantity AS FLOAT)) sx2,
                SUM(CAST(NetRevenue AS FLOAT) * CAST(NetRevenue AS FLOAT)) sy2
            FROM #PS2Base WHERE IsEligible = 1
        )
        SELECT @Pearson = CASE
            WHEN (n*sx2-sx*sx) <= 0 OR (n*sy2-sy*sy) <= 0 THEN NULL
            ELSE (n*sxy-sx*sy) / SQRT((n*sx2-sx*sx)*(n*sy2-sy*sy)) END
        FROM z;

        INSERT INTO gold.PS2_QuantityRevenue
        SELECT
            ProductID, ProductName, Category, Segment,
            SoldQuantity, ReturnQuantity, NetQuantity,
            GrossSales, DiscountAmount, RefundAmount, NetRevenue, NetCOGS, GrossProfit, GrossMargin,
            @H, @MarginThreshold,
            CASE WHEN IsEligible = 0 THEN NULL
                 WHEN NetQuantity >= @H AND GrossMargin < @MarginThreshold THEN 'A'
                 WHEN NetQuantity >= @H AND GrossMargin >= @MarginThreshold THEN 'B'
                 WHEN NetQuantity <  @H AND GrossMargin < @MarginThreshold THEN 'C'
                 ELSE 'D' END,
            IsEligible,
            CAST(@Pearson AS DECIMAL(19,10))
        FROM #PS2Base;

        -- // PS3: hiệu suất Category và Segment
        DROP TABLE IF EXISTS #PS3;
        ;WITH Cat AS (
            SELECT N'Category' AS ClassLevel, Category AS ClassName,
                   SUM(SoldQuantity) SoldQuantity, SUM(ReturnQuantity) ReturnQuantity,
                   SUM(NetQuantity) NetQuantity, SUM(NetRevenue) NetRevenue, SUM(GrossProfit) GrossProfit
            FROM #CompletedSales GROUP BY Category
        ), Seg AS (
            SELECT N'Segment', Segment,
                   SUM(SoldQuantity), SUM(ReturnQuantity), SUM(NetQuantity), SUM(NetRevenue), SUM(GrossProfit)
            FROM #CompletedSales GROUP BY Segment
        )
        SELECT * INTO #PS3 FROM (SELECT * FROM Cat UNION ALL SELECT * FROM Seg) x;

        INSERT INTO gold.PS3_ClassPerformance
        SELECT
            ClassLevel, ClassName, SoldQuantity, ReturnQuantity, NetQuantity,
            CAST(NetQuantity / NULLIF(SUM(CAST(NetQuantity AS DECIMAL(38,8))) OVER (PARTITION BY ClassLevel),0) AS DECIMAL(19,10)),
            CAST(NetRevenue AS DECIMAL(19,4)),
            CAST(NetRevenue / NULLIF(SUM(CAST(NetRevenue AS DECIMAL(38,8))) OVER (PARTITION BY ClassLevel),0) AS DECIMAL(19,10)),
            CAST(NetRevenue / NULLIF(CAST(NetQuantity AS DECIMAL(19,4)),0) AS DECIMAL(19,4)),
            CAST(GrossProfit AS DECIMAL(19,4)),
            CAST(GrossProfit / NULLIF(CAST(NetRevenue AS DECIMAL(19,4)),0) AS DECIMAL(19,8)),
            CAST(ReturnQuantity / NULLIF(CAST(SoldQuantity AS DECIMAL(19,4)),0) AS DECIMAL(19,8))
        FROM #PS3;

        -- // PS4: luân chuyển tồn kho
        DROP TABLE IF EXISTS #P4Sales;
        ;WITH Cat AS (
            SELECT N'Category' ClassLevel, Category ClassName, SUM(NetQuantity) NetQuantity, SUM(NetRevenue) NetRevenue
            FROM #CompletedSales GROUP BY Category
        ), Seg AS (
            SELECT N'Segment', Segment, SUM(NetQuantity), SUM(NetRevenue)
            FROM #CompletedSales GROUP BY Segment
        )
        SELECT * INTO #P4Sales FROM (SELECT * FROM Cat UNION ALL SELECT * FROM Seg) x;

        DROP TABLE IF EXISTS #P4Inv;
        ;WITH Base AS (
            SELECT fi.*, p.Category, p.Segment
            FROM dw.FactInventorySnapshot fi
            JOIN dw.DimProduct p ON p.ProductKey = fi.ProductKey
        ), Cat AS (
            SELECT N'Category' ClassLevel, Category ClassName,
                   AVG(CAST(SellThroughRate AS FLOAT)) AvgSellThrough,
                   AVG(CAST(DaysOfSupply AS FLOAT)) AvgDaysOfSupply,
                   AVG(CAST(FillRate AS FLOAT)) AvgFillRate,
                   AVG(CAST(StockoutFlag AS FLOAT)) StockoutRate,
                   AVG(CAST(OverstockFlag AS FLOAT)) OverstockRate,
                   COUNT(DISTINCT ProductKey) InventorySKU
            FROM Base GROUP BY Category
        ), Seg AS (
            SELECT N'Segment', Segment,
                   AVG(CAST(SellThroughRate AS FLOAT)), AVG(CAST(DaysOfSupply AS FLOAT)), AVG(CAST(FillRate AS FLOAT)),
                   AVG(CAST(StockoutFlag AS FLOAT)), AVG(CAST(OverstockFlag AS FLOAT)), COUNT(DISTINCT ProductKey)
            FROM Base GROUP BY Segment
        )
        SELECT * INTO #P4Inv FROM (SELECT * FROM Cat UNION ALL SELECT * FROM Seg) x;

        DROP TABLE IF EXISTS #P4Catalog;
        ;WITH Cat AS (
            SELECT N'Category' ClassLevel, Category ClassName, COUNT(*) CatalogSKU FROM dw.DimProduct GROUP BY Category
        ), Seg AS (
            SELECT N'Segment', Segment, COUNT(*) CatalogSKU FROM dw.DimProduct GROUP BY Segment
        )
        SELECT * INTO #P4Catalog FROM (SELECT * FROM Cat UNION ALL SELECT * FROM Seg) x;

        DROP TABLE IF EXISTS #P4;
        SELECT
            c.ClassLevel, c.ClassName, s.NetQuantity, s.NetRevenue,
            i.AvgSellThrough, i.AvgDaysOfSupply, i.AvgFillRate, i.StockoutRate, i.OverstockRate,
            c.CatalogSKU, i.InventorySKU
        INTO #P4
        FROM #P4Catalog c
        LEFT JOIN #P4Sales s ON s.ClassLevel=c.ClassLevel AND s.ClassName=c.ClassName
        LEFT JOIN #P4Inv i ON i.ClassLevel=c.ClassLevel AND i.ClassName=c.ClassName;

        DECLARE @CatLow FLOAT, @CatHigh FLOAT, @SegLow FLOAT, @SegHigh FLOAT;
        SELECT TOP(1) @CatLow = PERCENTILE_CONT(1.0/3.0) WITHIN GROUP (ORDER BY AvgSellThrough) OVER (),
                      @CatHigh = PERCENTILE_CONT(2.0/3.0) WITHIN GROUP (ORDER BY AvgSellThrough) OVER ()
        FROM #P4 WHERE ClassLevel=N'Category' AND AvgSellThrough IS NOT NULL;
        SELECT TOP(1) @SegLow = PERCENTILE_CONT(1.0/3.0) WITHIN GROUP (ORDER BY AvgSellThrough) OVER (),
                      @SegHigh = PERCENTILE_CONT(2.0/3.0) WITHIN GROUP (ORDER BY AvgSellThrough) OVER ()
        FROM #P4 WHERE ClassLevel=N'Segment' AND AvgSellThrough IS NOT NULL;

        INSERT INTO gold.PS4_InventoryTurnover
        SELECT
            ClassLevel, ClassName, NetQuantity,
            CAST(NetQuantity / NULLIF(SUM(CAST(NetQuantity AS DECIMAL(38,8))) OVER (PARTITION BY ClassLevel),0) AS DECIMAL(19,10)),
            CAST(NetRevenue AS DECIMAL(19,4)),
            CAST(AvgSellThrough AS DECIMAL(19,8)), CAST(AvgDaysOfSupply AS DECIMAL(19,4)),
            CAST(AvgFillRate AS DECIMAL(19,8)), CAST(StockoutRate AS DECIMAL(19,8)), CAST(OverstockRate AS DECIMAL(19,8)),
            CatalogSKU, InventorySKU,
            CAST(InventorySKU / NULLIF(CAST(CatalogSKU AS DECIMAL(19,8)),0) AS DECIMAL(19,8)),
            CASE
                WHEN AvgSellThrough IS NULL THEN NULL
                WHEN ClassLevel=N'Category' AND AvgSellThrough >= @CatHigh THEN N'Cao'
                WHEN ClassLevel=N'Category' AND AvgSellThrough <  @CatLow  THEN N'Thấp'
                WHEN ClassLevel=N'Category' THEN N'Trung bình'
                WHEN ClassLevel=N'Segment' AND AvgSellThrough >= @SegHigh THEN N'Cao'
                WHEN ClassLevel=N'Segment' AND AvgSellThrough <  @SegLow  THEN N'Thấp'
                ELSE N'Trung bình'
            END
        FROM #P4;

        -- // PS5: phân loại ABC
        DROP TABLE IF EXISTS #P5Base;
        SELECT
            p.ProductID, p.ProductName, p.Category, p.Segment,
            CAST(ISNULL(SUM(c.NetRevenue),0) AS DECIMAL(19,4)) AS NetRevenue,
            CAST(ISNULL(SUM(c.NetQuantity),0) AS INT) AS NetQuantity,
            COUNT(DISTINCT c.OrderID) AS Orders
        INTO #P5Base
        FROM dw.DimProduct p
        LEFT JOIN #CompletedSales c ON c.ProductKey = p.ProductKey
        GROUP BY p.ProductID, p.ProductName, p.Category, p.Segment;

        ;WITH r AS (
            SELECT *,
                ROW_NUMBER() OVER (ORDER BY NetRevenue DESC, NetQuantity DESC, ProductID ASC) AS ProductRank,
                CAST(NetRevenue / NULLIF(SUM(NetRevenue) OVER (),0) AS DECIMAL(19,10)) AS RevenueShare
            FROM #P5Base
        ), c AS (
            SELECT *,
                CAST(SUM(RevenueShare) OVER (ORDER BY ProductRank ROWS UNBOUNDED PRECEDING) AS DECIMAL(19,10)) AS CumulativeRevenueShare
            FROM r
        )
        INSERT INTO gold.PS5_ABC
        SELECT
            ProductRank, ProductID, ProductName, Category, Segment,
            NetRevenue, NetQuantity, Orders, RevenueShare, CumulativeRevenueShare,
            CASE WHEN CumulativeRevenueShare <= 0.80 THEN 'A'
                 WHEN CumulativeRevenueShare <= 0.95 THEN 'B'
                 ELSE 'C' END,
            CAST(CASE WHEN NetRevenue > 0 THEN 1 ELSE 0 END AS BIT)
        FROM c;

        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH
END;
GO

-- // Tạo view báo cáo
CREATE OR ALTER VIEW gold.vw_PS1_Top5 AS
SELECT TOP (5) * FROM gold.PS1_ProductRanking4M ORDER BY RevenueRank;
GO

CREATE OR ALTER VIEW gold.vw_PS1_Bottom5 AS
SELECT TOP (5) *
FROM gold.PS1_ProductRanking4M
WHERE InventoryRiskFlag = 1
ORDER BY StockOnHand DESC, InventoryCostValue DESC, ProductID;
GO

CREATE OR ALTER VIEW gold.vw_PS2_GroupA AS
SELECT * FROM gold.PS2_QuantityRevenue WHERE GroupLabel = 'A';
GO

CREATE OR ALTER VIEW gold.vw_PS3_Category AS
SELECT * FROM gold.PS3_ClassPerformance WHERE ClassLevel = N'Category';
GO

CREATE OR ALTER VIEW gold.vw_PS4_Category AS
SELECT * FROM gold.PS4_InventoryTurnover WHERE ClassLevel = N'Category';
GO

CREATE OR ALTER VIEW gold.vw_PS5_ABCSummary AS
SELECT
    ABCClass,
    COUNT(*) AS SKU,
    SUM(CASE WHEN IsActiveSKU=1 THEN 1 ELSE 0 END) AS ActiveSKU,
    SUM(NetRevenue) AS NetRevenue,
    SUM(NetQuantity) AS NetQuantity,
    CAST(COUNT(*) * 1.0 / SUM(COUNT(*)) OVER () AS DECIMAL(19,8)) AS SKUShare,
    CAST(SUM(NetRevenue) / NULLIF(SUM(SUM(NetRevenue)) OVER (),0) AS DECIMAL(19,8)) AS RevenueShare,
    CAST(SUM(NetRevenue) / NULLIF(COUNT(*),0) AS DECIMAL(19,4)) AS AvgRevenuePerSKU
FROM gold.PS5_ABC
GROUP BY ABCClass;
GO
