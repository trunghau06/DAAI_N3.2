-- // Tạo database và schema
IF DB_ID(N'Problem2_GoldDW') IS NULL
BEGIN
    CREATE DATABASE Problem2_GoldDW;
END;
GO

USE Problem2_GoldDW;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'silver') EXEC('CREATE SCHEMA silver');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'dw') EXEC('CREATE SCHEMA dw');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'etl') EXEC('CREATE SCHEMA etl');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'gold') EXEC('CREATE SCHEMA gold');
GO

-- // Tạo bảng Dimension và Fact
DROP TABLE IF EXISTS dw.FactInventorySnapshot;
DROP TABLE IF EXISTS dw.FactSales;
DROP TABLE IF EXISTS dw.DimOrderStatus;
DROP TABLE IF EXISTS dw.DimProduct;
DROP TABLE IF EXISTS dw.DimDate;
GO

CREATE TABLE dw.DimDate (
    DateKey      INT           NOT NULL PRIMARY KEY,
    FullDate     DATE          NOT NULL UNIQUE,
    DayNo        TINYINT       NOT NULL,
    MonthNo      TINYINT       NOT NULL,
    MonthName    NVARCHAR(20)  NOT NULL,
    QuarterNo    TINYINT       NOT NULL,
    YearNo       SMALLINT      NOT NULL
);

CREATE TABLE dw.DimProduct (
    ProductKey    INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    ProductID     INT            NOT NULL UNIQUE,
    ProductName   NVARCHAR(200)  NULL,
    Category      NVARCHAR(100)  NULL,
    Segment       NVARCHAR(100)  NULL,
    Size          NVARCHAR(50)   NULL,
    Color         NVARCHAR(50)   NULL,
    ListPrice     DECIMAL(19,4)  NULL,
    UnitCOGS      DECIMAL(19,4)  NULL
);

CREATE TABLE dw.DimOrderStatus (
    StatusKey    TINYINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    OrderStatus  NVARCHAR(50) NOT NULL UNIQUE
);

-- // Tạo Fact Sales
CREATE TABLE dw.FactSales (
    SalesKey            BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    OrderID             BIGINT         NOT NULL,
    DateKey             INT            NOT NULL,
    ProductKey          INT            NOT NULL,
    StatusKey           TINYINT        NOT NULL,
    SoldQuantity        INT            NOT NULL,
    ReturnQuantity      INT            NOT NULL,
    NetQuantity         INT            NOT NULL,
    GrossSales          DECIMAL(19,4)  NOT NULL,
    DiscountAmount      DECIMAL(19,4)  NOT NULL,
    SalesAfterDiscount  DECIMAL(19,4)  NOT NULL,
    RefundAmount        DECIMAL(19,4)  NOT NULL,
    NetRevenue          DECIMAL(19,4)  NOT NULL,
    NetCOGS             DECIMAL(19,4)  NULL,
    GrossProfit         DECIMAL(19,4)  NULL,
    GrossMargin         DECIMAL(19,8)  NULL,
    CONSTRAINT FK_FactSales_Date FOREIGN KEY (DateKey) REFERENCES dw.DimDate(DateKey),
    CONSTRAINT FK_FactSales_Product FOREIGN KEY (ProductKey) REFERENCES dw.DimProduct(ProductKey),
    CONSTRAINT FK_FactSales_Status FOREIGN KEY (StatusKey) REFERENCES dw.DimOrderStatus(StatusKey)
);
CREATE UNIQUE INDEX UX_FactSales_OrderProduct ON dw.FactSales(OrderID, ProductKey);
CREATE INDEX IX_FactSales_DateProduct ON dw.FactSales(DateKey, ProductKey);

-- // Tạo Fact Inventory
CREATE TABLE dw.FactInventorySnapshot (
    InventoryKey      BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    DateKey           INT            NOT NULL,
    ProductKey        INT            NOT NULL,
    StockOnHand       INT            NULL,
    UnitsReceived     INT            NULL,
    UnitsSold         INT            NULL,
    StockoutDays      INT            NULL,
    DaysOfSupply      DECIMAL(19,4)  NULL,
    FillRate          DECIMAL(19,6)  NULL,
    StockoutFlag      BIT            NULL,
    OverstockFlag     BIT            NULL,
    ReorderFlag       BIT            NULL,
    SellThroughRate   DECIMAL(19,6)  NULL,
    CONSTRAINT FK_FactInv_Date FOREIGN KEY (DateKey) REFERENCES dw.DimDate(DateKey),
    CONSTRAINT FK_FactInv_Product FOREIGN KEY (ProductKey) REFERENCES dw.DimProduct(ProductKey)
);
CREATE UNIQUE INDEX UX_FactInventory_DateProduct ON dw.FactInventorySnapshot(DateKey, ProductKey);
CREATE INDEX IX_FactInventory_ProductDate ON dw.FactInventorySnapshot(ProductKey, DateKey);
GO
